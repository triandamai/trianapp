/*eslint-disable*/
import { reactive } from "vue";
import { AuthGoogle, dbUser, getCurrentUser } from "@/store/firbaseDatabase";
import firebase from "firebase/app";
import { User } from "@/store/model-types";
import { useRouter } from "vue-router";

interface authState {
  result: authResult;
  isLoading: boolean;
  form: {
    email: string;
    password: string;
    username: string;
    repassword: string;
  };
  currentUser: any;
}
interface authResult {
  status: boolean;
  message: string;
}

const authState = reactive<authState>({
  result: {
    status: false,
    message: ""
  },
  isLoading: false,
  form: {
    email: "",
    username: "",
    password: "",
    repassword: ""
  },
  currentUser: ""
});
export function useAuth() {
  const router = useRouter();
  /**
   * get current user
   */
  function getAuthUser() {
    getCurrentUser().then(user => {
      authState.currentUser = user;
    });
  }
  /**
   * login
   */
  const loginWithGoogle = () => {
    const provider = new firebase.auth.GoogleAuthProvider();
    AuthGoogle.signInWithRedirect(provider);
  };

  const loginBasic = () => {
    authState.isLoading = true;
    AuthGoogle.signInWithEmailAndPassword(
      authState.form.email,
      authState.form.password
    )
      .then(user => {
        if (user.user?.uid) changelastLogin(`${user.user.uid}`);
        else
          authState.result = {
            status: false,
            message: "Gagal"
          };
      })
      .catch(e => {
        authState.result = {
          status: false,
          message: `${e}`
        };
      })
      .finally(() => {
        authState.isLoading = false;
      });
  };
  /**
   * register
   */
  const registerBasic = () => {
    authState.isLoading = true;
    if (authState.form.password != authState.form.repassword) return;
    if (authState.form.email == null && authState.form.username == null) return;

    AuthGoogle.createUserWithEmailAndPassword(
      authState.form.email,
      authState.form.password
    )
      .then(user => {
        AuthGoogle.currentUser?.updateProfile({
          displayName: authState.form.username
        });
        if (user)
          setUser(
            {
              username: authState.form.username,
              email: authState.form.email,
              password: authState.form.password,
              uuid: `${user.user?.uid}`,
              createdAt: Date.now().toLocaleString(),
              updatedAt: Date.now().toLocaleString(),
              authMethod: "basic"
            },
            true
          );
        else
          authState.result = {
            status: false,
            message: "gagal"
          };
      })
      .catch(e => {
        authState.result = { status: false, message: `${e}` };
      })
      .finally(() => {
        authState.isLoading = false;
      });
  };
  const resultFromredirectGoogle = (isLogin: boolean) => {
    authState.isLoading = true;
    AuthGoogle.getRedirectResult()
      .then(result => {
        if (result.user)
          if (!result.additionalUserInfo?.isNewUser)
            return changelastLogin(`${result.user?.uid}`);
          else
            setUser(
              {
                username: `${result.user?.displayName}`,
                email: `${result.user?.email}`,
                password: `${result.user?.uid}`,
                createdAt: Date.now().toLocaleString(),
                updatedAt: Date.now().toLocaleString(),
                authMethod: "google",
                uuid: `${result.user?.uid}`
              },
              false
            );
        else return (authState.result = { status: false, message: "Gagal" });
      })
      .catch(e => {
        authState.result = {
          status: false,
          message: `${e}`
        };
      })
      .finally(() => {
        authState.isLoading = false;
      });
  };

  const setUser = (user: User, shouldLogin: boolean) => {
    dbUser
      .doc(user.uuid)
      .set(user, { merge: true })
      .then(() => {
        if (shouldLogin) return router.push({ path: "/auth" });
        router.push({ path: "/dashboard" });
      });
  };

  const changelastLogin = (uuid: string) => {
    dbUser
      .doc(uuid)
      .set({ updatedAt: Date.now().toLocaleString() }, { merge: true })
      .then(() => {
        router.push({ path: "/dashboard" });
      });
  };

  function userSignOut() {
    AuthGoogle.signOut()
      .then(res => {
        router.push({ path: "/auth" });
      })
      .catch(e => {});
  }

  return {
    authState,
    loginBasic,
    loginWithGoogle,
    registerBasic,
    resultFromredirectGoogle,
    getAuthUser,
    userSignOut
  };
}
